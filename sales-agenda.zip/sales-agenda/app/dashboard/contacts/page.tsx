"use client";

import { useEffect, useMemo, useState } from "react";

type Contact = {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  company: string | null;
  status: "NEW" | "IN_PROGRESS" | "QUALIFIED" | "CLOSED";
};

export default function ContactsPage() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("");
  const [rows, setRows] = useState<Contact[]>([]);
  const [err, setErr] = useState("");

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (status) p.set("status", status);
    return p.toString();
  }, [q, status]);

  useEffect(() => {
    (async () => {
      setErr("");
      const res = await fetch(`/api/contacts?${qs}`);
      const json = await res.json();
      if (!res.ok) return setErr(json.error || "Error");
      setRows(json);
    })();
  }, [qs]);

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Contactos</h2>

      <div className="flex gap-2">
        <input className="border rounded px-3 py-2 w-full" placeholder="Buscar" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="border rounded px-3 py-2" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todos</option>
          <option value="NEW">New</option>
          <option value="IN_PROGRESS">In progress</option>
          <option value="QUALIFIED">Qualified</option>
          <option value="CLOSED">Closed</option>
        </select>
      </div>

      {err && <p className="text-red-600 text-sm">{err}</p>}

      <div className="bg-white border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-600">
            <tr>
              <th className="text-left p-3">Nombre</th>
              <th className="text-left p-3">Empresa</th>
              <th className="text-left p-3">Teléfono</th>
              <th className="text-left p-3">Estado</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="p-3 font-medium">{c.name}</td>
                <td className="p-3">{c.company ?? "-"}</td>
                <td className="p-3">{c.phone ?? "-"}</td>
                <td className="p-3">{c.status}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td className="p-3 text-gray-500" colSpan={4}>Sin resultados</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
