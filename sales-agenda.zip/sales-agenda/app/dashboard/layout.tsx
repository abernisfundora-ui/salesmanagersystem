export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center gap-4">
          <a className="font-semibold" href="/dashboard">Dashboard</a>
          <nav className="flex gap-3 text-sm text-gray-700">
            <a className="hover:underline" href="/dashboard/contacts">Contactos</a>
            <a className="hover:underline" href="/dashboard/calendar">Calendario</a>
            <a className="hover:underline" href="/dashboard/agents">Mis agentes</a>
          </nav>
          <div className="ml-auto">
            <form action="/api/auth/logout" method="post">
              <button className="text-sm px-3 py-2 rounded bg-gray-200">Logout</button>
            </form>
          </div>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-6 py-6">{children}</main>
    </div>
  );
}
