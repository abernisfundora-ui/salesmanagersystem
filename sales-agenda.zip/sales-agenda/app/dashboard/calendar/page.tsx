"use client";

import { useEffect, useMemo, useState } from "react";

type DaySummary = { day: string; sales: number; appointments: number };

function ymd(d: Date) {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function CalendarPage() {
  const [monthOffset, setMonthOffset] = useState(0);
  const [data, setData] = useState<DaySummary[]>([]);

  const { from, to, label } = useMemo(() => {
    const now = new Date();
    const first = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + monthOffset, 1, 0, 0, 0));
    const last = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + monthOffset + 1, 0, 23, 59, 59));
    const label = first.toLocaleString("es-ES", { month: "long", year: "numeric", timeZone: "UTC" });
    return { from: first.toISOString(), to: last.toISOString(), label };
  }, [monthOffset]);

  useEffect(() => {
    (async () => {
      const res = await fetch(`/api/calendar/summary?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
      const json = await res.json();
      if (res.ok) setData(json);
      else setData([]);
    })();
  }, [from, to]);

  const map = useMemo(() => new Map(data.map((d) => [d.day, d])), [data]);

  const days = useMemo(() => {
    const start = new Date(from);
    const end = new Date(to);
    const out: string[] = [];
    // iterate days in UTC
    const cur = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate(), 0, 0, 0));
    while (cur <= end) {
      out.push(ymd(cur));
      cur.setUTCDate(cur.getUTCDate() + 1);
    }
    return out;
  }, [from, to]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <h2 className="text-xl font-semibold capitalize">Calendario — {label}</h2>
        <div className="ml-auto flex gap-2">
          <button className="px-3 py-2 rounded bg-gray-200" onClick={() => setMonthOffset((x) => x - 1)}>◀</button>
          <button className="px-3 py-2 rounded bg-gray-200" onClick={() => setMonthOffset(0)}>Hoy</button>
          <button className="px-3 py-2 rounded bg-gray-200" onClick={() => setMonthOffset((x) => x + 1)}>▶</button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {days.map((d) => {
          const s = map.get(d);
          const dayNum = Number(d.slice(-2));
          return (
            <div key={d} className="bg-white border rounded-lg p-2 h-24 relative">
              <div className="text-sm text-gray-700">{dayNum}</div>
              <div className="absolute bottom-2 left-2 flex gap-1">
                {s?.sales ? (
                  <span className="bg-green-600 text-white text-xs px-2 py-1 rounded-full">{s.sales}</span>
                ) : null}
                {s?.appointments ? (
                  <span className="bg-purple-600 text-white text-xs px-2 py-1 rounded-full">{s.appointments}</span>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-sm text-gray-600">🟢 ventas (FUTURE + CLOSED). 🟣 citas (no canceladas).</p>
    </div>
  );
}
