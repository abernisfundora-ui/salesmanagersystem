import { PrismaClient, Role, ContactStatus, AppointmentStatus, SaleStatus } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

function cents(n: number) {
  return Math.round(n * 100);
}

function atUTCDatePlus(days: number, hour = 15, minute = 0) {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + days, hour, minute, 0));
}

async function main() {
  await prisma.sale.deleteMany();
  await prisma.appointment.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.membership.deleteMany();
  await prisma.tenant.deleteMany();
  await prisma.user.deleteMany();

  const tenant = await prisma.tenant.create({
    data: {
      name: "Demo Company",
      slug: "demo-company-" + Math.random().toString(16).slice(2, 6),
      plan: "pro",
    },
  });

  const passwordHash = await bcrypt.hash("123456", 10);

  const manager = await prisma.user.create({
    data: { name: "Gerente Demo", email: "manager@demo.com", passwordHash },
  });
  const agent1 = await prisma.user.create({
    data: { name: "Agente Raul", email: "raul@demo.com", passwordHash },
  });
  const agent2 = await prisma.user.create({
    data: { name: "Agente Ana", email: "ana@demo.com", passwordHash },
  });
  const secretary = await prisma.user.create({
    data: { name: "Secretaria Mia", email: "secretary@demo.com", passwordHash },
  });

  await prisma.membership.createMany({
    data: [
      { tenantId: tenant.id, userId: manager.id, role: Role.MANAGER, status: "ACTIVE" },
      { tenantId: tenant.id, userId: agent1.id, role: Role.AGENT, status: "ACTIVE" },
      { tenantId: tenant.id, userId: agent2.id, role: Role.AGENT, status: "ACTIVE" },
      { tenantId: tenant.id, userId: secretary.id, role: Role.SECRETARY, status: "ACTIVE" },
    ],
  });

  await prisma.contact.createMany({
    data: [
      {
        tenantId: tenant.id,
        createdById: secretary.id,
        assignedAgentId: agent1.id,
        name: "Juan Perez",
        phone: "+1 555 100 200",
        email: "juan@correo.com",
        company: "JP Holdings",
        status: ContactStatus.NEW,
      },
      {
        tenantId: tenant.id,
        createdById: secretary.id,
        assignedAgentId: agent1.id,
        name: "Maria Lopez",
        phone: "+1 555 300 400",
        email: "maria@correo.com",
        company: "Lopez LLC",
        status: ContactStatus.IN_PROGRESS,
      },
      {
        tenantId: tenant.id,
        createdById: manager.id,
        assignedAgentId: agent2.id,
        name: "Carlos Diaz",
        phone: "+1 555 777 111",
        email: "carlos@correo.com",
        company: "Diaz Group",
        status: ContactStatus.QUALIFIED,
      },
      {
        tenantId: tenant.id,
        createdById: manager.id,
        assignedAgentId: agent2.id,
        name: "Sofia Martinez",
        phone: "+1 555 888 222",
        email: "sofia@correo.com",
        company: "Martinez Inc",
        status: ContactStatus.CLOSED,
      },
    ],
  });

  const contactList = await prisma.contact.findMany({ where: { tenantId: tenant.id }, orderBy: { createdAt: "asc" } });
  const [c1, c2, c3, c4] = contactList;

  await prisma.appointment.createMany({
    data: [
      {
        tenantId: tenant.id,
        contactId: c1.id,
        agentId: agent1.id,
        createdById: secretary.id,
        startsAt: atUTCDatePlus(0, 16, 0),
        endsAt: atUTCDatePlus(0, 17, 0),
        notes: "Primera llamada / evaluación",
        status: AppointmentStatus.SCHEDULED,
      },
      {
        tenantId: tenant.id,
        contactId: c2.id,
        agentId: agent1.id,
        createdById: secretary.id,
        startsAt: atUTCDatePlus(1, 16, 0),
        endsAt: atUTCDatePlus(1, 17, 0),
        notes: "Seguimiento",
        status: AppointmentStatus.SCHEDULED,
      },
      {
        tenantId: tenant.id,
        contactId: c3.id,
        agentId: agent2.id,
        createdById: manager.id,
        startsAt: atUTCDatePlus(2, 16, 0),
        endsAt: atUTCDatePlus(2, 17, 0),
        notes: "Demo del producto",
        status: AppointmentStatus.SCHEDULED,
      },
      {
        tenantId: tenant.id,
        contactId: c4.id,
        agentId: agent2.id,
        createdById: manager.id,
        startsAt: atUTCDatePlus(-2, 16, 0),
        endsAt: atUTCDatePlus(-2, 17, 0),
        notes: "Cita completada",
        status: AppointmentStatus.COMPLETED,
      },
    ],
  });

  await prisma.sale.createMany({
    data: [
      {
        tenantId: tenant.id,
        contactId: c1.id,
        agentId: agent1.id,
        createdById: manager.id,
        status: SaleStatus.FUTURE,
        profitCents: cents(300),
        saleDate: atUTCDatePlus(0, 18, 0),
        title: "Venta esperada - Plan Básico",
        notes: "Pendiente confirmación",
        currency: "USD",
      },
      {
        tenantId: tenant.id,
        contactId: c2.id,
        agentId: agent1.id,
        createdById: manager.id,
        status: SaleStatus.CLOSED,
        profitCents: cents(500),
        saleDate: atUTCDatePlus(0, 19, 0),
        title: "Venta cerrada - Plan Pro",
        notes: "Pago recibido",
        currency: "USD",
      },
      {
        tenantId: tenant.id,
        contactId: c4.id,
        agentId: agent2.id,
        createdById: manager.id,
        status: SaleStatus.CLOSED,
        profitCents: cents(700),
        saleDate: atUTCDatePlus(-10, 19, 0),
        title: "Venta cerrada - Enterprise",
        notes: "Contrato firmado",
        currency: "USD",
      },
      {
        tenantId: tenant.id,
        contactId: c3.id,
        agentId: agent2.id,
        createdById: manager.id,
        status: SaleStatus.FUTURE,
        profitCents: cents(400),
        saleDate: atUTCDatePlus(5, 19, 0),
        title: "Venta esperada - Add-on",
        notes: "En negociación",
        currency: "USD",
      }
    ],
  });

  console.log("✅ Seed completado");
  console.log("Login demo:");
  console.log("MANAGER   manager@demo.com    pass: 123456");
  console.log("AGENT     raul@demo.com       pass: 123456");
  console.log("AGENT     ana@demo.com        pass: 123456");
  console.log("SECRETARY secretary@demo.com  pass: 123456");
}

main()
  .catch((e) => {
    console.error("❌ Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
