# Sales Agenda (MVP funcional)

## Requisitos
- Node 18+
- PostgreSQL

## Setup
1) Instala dependencias
```bash
npm install
```

2) Crea `.env` basado en `.env.example`

3) Prisma
```bash
npx prisma generate
npx prisma migrate dev --name init
npm run seed
```

4) Ejecuta
```bash
npm run dev
```

## Logins demo (después del seed)
- manager@demo.com / 123456
- raul@demo.com / 123456
- ana@demo.com / 123456
- secretary@demo.com / 123456

## Roles
- MANAGER: ve todo + gestiona agentes/secretaria
- AGENT: ve solo lo suyo
- SECRETARY: crea contactos/citas, **no ve ganancias**, no crea ventas, no gestiona agentes
