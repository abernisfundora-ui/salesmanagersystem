export type Role = "OWNER" | "ADMIN" | "MANAGER" | "AGENT" | "SECRETARY";

export const canManageTeam = (role: Role) =>
  role === "OWNER" || role === "ADMIN" || role === "MANAGER";

export const canViewAllTenantData = (role: Role) =>
  role === "OWNER" || role === "ADMIN" || role === "MANAGER";

// SECRETARY NO ve financials
export const canViewFinancials = (role: Role) =>
  role === "OWNER" || role === "ADMIN" || role === "MANAGER" || role === "AGENT";

export const canCreateAppointment = (role: Role) =>
  role === "OWNER" || role === "ADMIN" || role === "MANAGER" || role === "AGENT" || role === "SECRETARY";

export const canCreateSale = (role: Role) =>
  role === "OWNER" || role === "ADMIN" || role === "MANAGER" || role === "AGENT";
